﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace QuanLySach.Models
{
    public class Review
    {
        public string Name { get; set; } = null!;
        public string Description { get; set; } = null!;
        public int Rate { get; set; }
        public Book? Book { get; set; }
        public Reviewer? Reviewer { get; set; }
    }
}