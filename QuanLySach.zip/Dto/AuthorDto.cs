﻿namespace QuanLySach.Dto
{
    public class AuthorDto
    {
        public int Id { get; set; }   
        public required string Name { get; set; }
    }
}
