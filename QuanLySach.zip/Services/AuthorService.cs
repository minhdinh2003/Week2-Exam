using Microsoft.EntityFrameworkCore;
using QuanLySach.Data;
using QuanLySach.Dto;
using QuanLySach.Models;

namespace QuanLySach.Services
{
    public class AuthorService(AppDbContext dbContext)
    {
        private readonly AppDbContext _dbContext = dbContext;

        public async Task<List<Author>> GetAuthorsAsync()
        {
            return await _dbContext.Authors.ToListAsync();
        }

        public async Task<Author?> GetAuthorAsync(int id)
        {
            return await _dbContext.Authors.FindAsync(id);
        }

        public async Task<object?> GetBooksByAuthorAsync(int id)
        {
            var author = await _dbContext.Authors
                .Where(a => a.Id == id)
                .Include(b => b.Books)
                .FirstOrDefaultAsync();
            if (author == null) return null;
            return new
            {
                author.Id,
                author.Name,
                books = author.Books.Select(r => new { r.Id, r.Title }).ToList()
            };
        }

        public async Task<Author> AddAuthorAsync(AuthorDto authorDto)
        {
            var author = new Author { Name = authorDto.Name };
            _dbContext.Authors.Add(author);
            await _dbContext.SaveChangesAsync();
            return author;
        }

        public async Task<bool> UpdateAuthorAsync(int id, AuthorDto authorDto)
        {
            if (id != authorDto.Id) return false;
            var author = await _dbContext.Authors.FindAsync(id);
            if (author == null) return false;
            author.Name = authorDto.Name;
            _dbContext.Entry(author).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAuthorAsync(int id)
        {
            var author = await _dbContext.Authors.FindAsync(id);
            if (author == null) return false;
            _dbContext.Authors.Remove(author);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}