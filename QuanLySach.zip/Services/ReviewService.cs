using Microsoft.Extensions.Options;
using MongoDB.Driver;
using QuanLySach.Dto;
using QuanLySach.Models;
using QuanLySach.Data;

namespace QuanLySach.Services
{
    public class ReviewService
    {
        private readonly IMongoCollection<Review> _reviews;
        private readonly AppDbContext _dbContext;

        public ReviewService(IOptions<MongoDbSettings> mongoSettings, AppDbContext dbContext)
        {
            var client = new MongoClient(mongoSettings.Value.ConnectionString);
            var database = client.GetDatabase(mongoSettings.Value.Database);
            _reviews = database.GetCollection<Review>("Reviews");
            _dbContext = dbContext;
        }

        public async Task<bool> AddReviewAsync(ReviewDto reviewDto)
        {
            var book = await _dbContext.Books.FindAsync(reviewDto.BookId);
            var reviewer = await _dbContext.Reviewers.FindAsync(reviewDto.ReviewerId);

            if (book == null || reviewer == null)
            {
                return false;
            }

            var review = new Review
            {
                Name = reviewDto.Name,
                Description = reviewDto.Description,
                Rate = reviewDto.Rate,
                Book = book,
                Reviewer = reviewer
            };

            try
            {
                await _reviews.InsertOneAsync(review);
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
