using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using QuanLySach.Data;
using QuanLySach.Dto;
using QuanLySach.Models;

namespace QuanLySach.Services
{
    public class BookService(AppDbContext dbContext, IMongoCollection<Review> reviews)
    {
        private readonly AppDbContext _dbContext = dbContext;
        private readonly IMongoCollection<Review> _reviews = reviews;
        public async Task<List<Book>> GetBooksAsync()
        {
            return await _dbContext.Books.ToListAsync();
        }

        public async Task<Book?> GetBookAsync(int id)
        {
            return await _dbContext.Books.FindAsync(id);
        }

        public async Task<object?> GetReviewsByBookAsync(int id)
        {
            var book = await _dbContext.Books.FindAsync(id);
            if (book == null) return null;

            var reviews = await _reviews.Find(r => r.Book.Id == id).ToListAsync();

            return new
            {
                book.Id,
                book.Title,
                book.AuthorId,
                Reviews = reviews.Select(r => new
                {
                    r.Name,
                    r.Description,
                    r.Rate,
                    r.Reviewer
                }).ToList()
            };
        }

        public async Task<Book> AddBookAsync(BookDto bookDto)
        {
            var book = new Book
            {
                Id = bookDto.Id,
                Title = bookDto.Title,
                AuthorId = bookDto.AuthorId
            };
            _dbContext.Books.Add(book);
            await _dbContext.SaveChangesAsync();
            return book;
        }

        public async Task<bool> UpdateBookAsync(int id, BookDto bookDto)
        {
            if (id != bookDto.Id) return false;
            var book = await _dbContext.Books.FindAsync(id);
            if (book == null) return false;
            book.Title = bookDto.Title;
            book.AuthorId = bookDto.AuthorId;
            _dbContext.Entry(book).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteBookAsync(int id)
        {
            var book = await _dbContext.Books.FindAsync(id);
            if (book == null) return false;
            _dbContext.Books.Remove(book);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}