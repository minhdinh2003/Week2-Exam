using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using QuanLySach.Data;
using QuanLySach.Dto;
using QuanLySach.Models;

namespace QuanLySach.Services
{
    public class ReviewerService(AppDbContext dbContext, IMongoCollection<Review> reviews)
    {
        private readonly AppDbContext _dbContext = dbContext;
        private readonly IMongoCollection<Review> _reviews = reviews;

        public async Task<List<Reviewer>> GetReviewersAsync()
        {
            return await _dbContext.Reviewers.ToListAsync();
        }

        public async Task<Reviewer?> GetReviewerAsync(int id)
        {
            return await _dbContext.Reviewers.FindAsync(id);
        }

        public async Task<object?> GetReviewsByReviewerAsync(int id)
        {
            // Lấy reviewer từ MSSQL
            var reviewer = await _dbContext.Reviewers.FindAsync(id);
            if (reviewer == null) return null;

            // Lấy reviews từ MongoDB
            var reviews = await _reviews.Find(r => r.Reviewer.Id == id).ToListAsync();

            // Trả về reviewer kèm danh sách reviews
            return new
            {
                Reviewer = reviewer,
                Reviews = reviews
            };
        }

        public async Task<Reviewer?> AddReviewerAsync(ReviewerDto reviewerDto)
        {
            using var transaction = await _dbContext.Database.BeginTransactionAsync();
            try
            {
                var reviewer = new Reviewer
                {
                    Id = reviewerDto.Id,
                    Name = reviewerDto.Name
                };
                _dbContext.Reviewers.Add(reviewer);
                await _dbContext.SaveChangesAsync();
                await transaction.CommitAsync();
                return reviewer;
            }
            catch
            {
                await transaction.RollbackAsync();
                return null;
            }
        }

        public async Task<bool> UpdateReviewerAsync(int id, ReviewerDto reviewerDto)
        {
            if (id != reviewerDto.Id) return false;
            var reviewer = await _dbContext.Reviewers.FindAsync(id);
            if (reviewer == null) return false;
            reviewer.Name = reviewerDto.Name;
            _dbContext.Entry(reviewer).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteReviewerAsync(int id)
        {
            var reviewer = await _dbContext.Reviewers.FindAsync(id);
            if (reviewer == null) return false;
            _dbContext.Reviewers.Remove(reviewer);
            await _dbContext.SaveChangesAsync();
            return true;
        }
    }
}