﻿using Microsoft.AspNetCore.Mvc;
using QuanLySach.Dto;
using QuanLySach.Models;
using QuanLySach.Services;

namespace QuanLySach.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthorController(AuthorService authorService) : ControllerBase
    {
        private readonly AuthorService _authorService = authorService;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Author>>> GetAuthors()
        {
            var authors = await _authorService.GetAuthorsAsync();
            return Ok(authors);
        }

        [HttpGet("{id}/books")]
        public async Task<ActionResult> GetBooks(int id)
        {
            var result = await _authorService.GetBooksByAuthorAsync(id);
            return result == null ? NotFound() : Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<Author>> AddAuthor(AuthorDto authorDto)
        {
            if (authorDto == null || string.IsNullOrWhiteSpace(authorDto.Name))
            {
                return BadRequest("Author data is invalid.");
            }
            var author = await _authorService.AddAuthorAsync(authorDto);
            return CreatedAtAction(nameof(GetAuthors), new { id = author.Id }, author);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Author>> GetAuthor(int id)
        {
            var author = await _authorService.GetAuthorAsync(id);
            return author == null ? (ActionResult<Author>)NotFound() : (ActionResult<Author>)Ok(author);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAuthor(int id, AuthorDto authorDto)
        {
            if (authorDto == null || id != authorDto.Id || string.IsNullOrWhiteSpace(authorDto.Name))
            {
                return BadRequest("Author data is invalid.");
            }
            var updated = await _authorService.UpdateAuthorAsync(id, authorDto);
            if (!updated) return BadRequest();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAuthor(int id)
        {
            var deleted = await _authorService.DeleteAuthorAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}