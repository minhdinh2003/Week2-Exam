﻿using Microsoft.AspNetCore.Mvc;
using QuanLySach.Dto;
using QuanLySach.Services;

namespace QuanLySach.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReviewController(ReviewService reviewService) : ControllerBase
    {
        private readonly ReviewService _reviewService = reviewService;

        [HttpPost("review")]
        public async Task<IActionResult> AddReview([FromBody] ReviewDto reviewDto)
        {
            var result = await _reviewService.AddReviewAsync(reviewDto);
            return !result ? BadRequest("Book or Reviewer not found, or error occurred.") : Ok("Enrollment successful.");
        }
    }
}