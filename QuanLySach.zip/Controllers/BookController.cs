﻿using Microsoft.AspNetCore.Mvc;
using QuanLySach.Dto;
using QuanLySach.Models;
using QuanLySach.Services;

namespace QuanLySach.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookController(BookService bookService) : ControllerBase
    {
        private readonly BookService _bookService = bookService;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Book>>> GetBooks()
        {
            var books = await _bookService.GetBooksAsync();
            return Ok(books);
        }

        [HttpGet("{id}/reviews")]
        public async Task<ActionResult> GetReviews(int id)
        {
            var result = await _bookService.GetReviewsByBookAsync(id);
            return result == null ? BadRequest() : Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<Book>> AddBook(BookDto bookDto)
        {
            if (bookDto == null || string.IsNullOrWhiteSpace(bookDto.Title))
            {
                return BadRequest("Book data is invalid.");
            }
            try
            {
                var book = await _bookService.AddBookAsync(bookDto);
                return CreatedAtAction(nameof(GetBooks), new { id = book.Id }, book);
            }
            catch (Exception)
            {
                return BadRequest("Invalid Author ID");
            }
            
            
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Book>> GetBook(int id)
        {
            var book = await _bookService.GetBookAsync(id);
            return book == null ? (ActionResult<Book>)NotFound() : (ActionResult<Book>)Ok(book);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBook(int id, BookDto bookDto)
        {
            var updated = await _bookService.UpdateBookAsync(id, bookDto);
            return !updated ? BadRequest() : NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var deleted = await _bookService.DeleteBookAsync(id);
            return !deleted ? NotFound() : NoContent();
        }
    }
}