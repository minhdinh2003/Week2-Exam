﻿using Microsoft.AspNetCore.Mvc;
using QuanLySach.Dto;
using QuanLySach.Models;
using QuanLySach.Services;

namespace QuanLySach.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReviewerController(ReviewerService reviewerService) : ControllerBase
    {
        private readonly ReviewerService _reviewerService = reviewerService;

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Reviewer>>> GetReviewers()
        {
            var reviewers = await _reviewerService.GetReviewersAsync();
            return Ok(reviewers);
        }

        [HttpGet("{id}/review")]
        public async Task<ActionResult> GetReviews(int id)
        {
            var result = await _reviewerService.GetReviewsByReviewerAsync(id);
            if (result == null) return BadRequest();
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<Reviewer>> AddReviewer(ReviewerDto reviewerDto)
        {
            var reviewer = await _reviewerService.AddReviewerAsync(reviewerDto);
            if (reviewer == null)
                return StatusCode(500, "An error occurred during enrollment. The transaction was rolled back.");
            return CreatedAtAction(nameof(GetReviewers), new { id = reviewer.Id }, reviewer);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Reviewer>> GetReviewer(int id)
        {
            var reviewer = await _reviewerService.GetReviewerAsync(id);
            if (reviewer == null) return NotFound();
            return Ok(reviewer);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateReviewer(int id, ReviewerDto reviewerDto)
        {
            var updated = await _reviewerService.UpdateReviewerAsync(id, reviewerDto);
            if (!updated) return BadRequest("ID in URL does not match ID in body or reviewer not found.");
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteReviewer(int id)
        {
            var deleted = await _reviewerService.DeleteReviewerAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}